export default {
    background: '#0b1020',
    surface: '#11193b',
    surfaceAlt: '#1b2556',
    primary: '#7c5cff',
    accent: '#22d3ee',
    text: '#e5e7eb',
    muted: '#94a3b8',
    danger: '#ef4444',
    success: '#22c55e'
  };
  