import { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import PrimaryButton from '../components/PrimaryButton';
import LayoutCard from '../components/LayoutCard';
import AppModal from '../components/AppModal';
import colors from '../theme/colors';
import { useTracker } from '../context/TrackerContext';
import { todayKey } from '../utils/date';

export default function AddEntryScreen() {
  const { entries, add } = useTracker();
  const today = todayKey();
  const existing = entries.find(e => e.date === today);

  const [mood, setMood] = useState(existing?.mood || 3);
  const [water, setWater] = useState(String(existing?.water ?? '0'));
  const [tasks, setTasks] = useState(String(existing?.tasks ?? '0'));
  const [notes, setNotes] = useState(existing?.notes || '');
  const [modal, setModal] = useState(false);

  useEffect(() => {
    if (existing) {
      setMood(existing.mood);
      setWater(String(existing.water));
      setTasks(String(existing.tasks));
      setNotes(existing.notes);
    }
  }, []);

  const onSave = async () => {
    const entry = {
      id: today,          // one entry per day (id = date)
      date: today,
      mood: Number(mood),
      water: Number(water) || 0,
      tasks: Number(tasks) || 0,
      notes: notes?.trim()
    };
    await add(entry);
    setModal(true);
  };

  return (
    <View style={styles.container}>
      <LayoutCard>
        <Text style={styles.label}>Mood (1-5)</Text>
        <View style={styles.pickerWrap}>
          <Picker selectedValue={mood} onValueChange={setMood} dropdownIconColor="white">
            {[1,2,3,4,5].map(n => <Picker.Item key={n} label={String(n)} value={n} color="#000" />)}
          </Picker>
        </View>

        <Text style={styles.label}>Water (glasses)</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={water}
          onChangeText={setWater}
          placeholder="0"
          placeholderTextColor="#64748b"
        />

        <Text style={styles.label}>Tasks Completed</Text>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          value={tasks}
          onChangeText={setTasks}
          placeholder="0"
          placeholderTextColor="#64748b"
        />

        <Text style={styles.label}>Notes</Text>
        <TextInput
          style={[styles.input, { height: 90, textAlignVertical: 'top' }]}
          value={notes}
          onChangeText={setNotes}
          placeholder="How did your day go?"
          placeholderTextColor="#64748b"
          multiline
        />

        <PrimaryButton title="Save Entry" onPress={onSave} />
      </LayoutCard>

      <AppModal
        visible={modal}
        title="Saved!"
        message="Your daily entry has been saved locally."
        onClose={() => setModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, gap: 16, backgroundColor: colors.background },
  label: { color: colors.text, marginBottom: 6, fontWeight: '700' },
  pickerWrap: { backgroundColor: colors.surfaceAlt, borderRadius: 12, marginBottom: 10, overflow: 'hidden' },
  input: {
    backgroundColor: colors.surfaceAlt,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: 'white',
    marginBottom: 12
  }
});
