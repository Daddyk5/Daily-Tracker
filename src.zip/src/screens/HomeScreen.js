import { View, Text, StyleSheet } from 'react-native';
import LayoutCard from '../components/LayoutCard';
import PrimaryButton from '../components/PrimaryButton';
import colors from '../theme/colors';
import { useNavigation } from '@react-navigation/native';
import { useTracker } from '../context/TrackerContext';
import LoadingOverlay from '../components/LoadingOverlay';
import StatBadge from '../components/StatBadge';
import { todayKey } from '../utils/date';

export default function HomeScreen() {
  const nav = useNavigation();
  const { entries, booting } = useTracker();

  if (booting) return <LoadingOverlay label="Preparing your tracker..." />;

  const today = todayKey();
  const todayEntry = entries.find(e => e.date === today);

  const avgMood =
    entries.length ? (entries.reduce((a, b) => a + (b.mood || 0), 0) / entries.length).toFixed(1) : '–';
  const totalWater = entries.reduce((a, b) => a + (Number(b.water) || 0), 0);
  const totalTasks = entries.reduce((a, b) => a + (Number(b.tasks) || 0), 0);

  return (
    <View style={styles.container}>
      <LayoutCard>
        <Text style={styles.title}>Today</Text>
        <Text style={styles.subtitle}>
          {todayEntry ? `Mood ${todayEntry.mood}/5 • Water ${todayEntry.water} • Tasks ${todayEntry.tasks}` : 'No entry yet'}
        </Text>
        <PrimaryButton
          title={todayEntry ? 'Update Today' : 'Add Today\'s Entry'}
          onPress={() => nav.navigate('AddEntry')}
        />
      </LayoutCard>

      <View style={styles.grid}>
        <StatBadge label="Avg Mood" value={avgMood} />
        <StatBadge label="Total Water" value={totalWater} />
        <StatBadge label="Total Tasks" value={totalTasks} />
      </View>

      <LayoutCard>
        <Text style={styles.title}>History</Text>
        <PrimaryButton title="Open History" onPress={() => nav.navigate('History')} />
      </LayoutCard>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, gap: 16, backgroundColor: colors.background },
  title: { color: 'white', fontSize: 18, fontWeight: '800' },
  subtitle: { color: colors.muted, marginBottom: 10 },
  grid: { flexDirection: 'row', gap: 12, justifyContent: 'space-between' }
});
