import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = '@daily_tracker_entries_v1';

export async function loadEntries() {
  const raw = await AsyncStorage.getItem(KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveEntries(entries) {
  await AsyncStorage.setItem(KEY, JSON.stringify(entries));
}

export async function addEntry(entry) {
  const entries = await loadEntries();
  const newEntries = [entry, ...entries].slice(0, 500); // keep last 500
  await saveEntries(newEntries);
  return newEntries;
}

export async function deleteEntry(id) {
  const entries = await loadEntries();
  const filtered = entries.filter(e => e.id !== id);
  await saveEntries(filtered);
  return filtered;
}

export async function clearAll() {
  await AsyncStorage.removeItem(KEY);
  return [];
}
