import { ActivityIndicator, View, StyleSheet, Text } from 'react-native';
import colors from '../theme/colors';

export default function LoadingOverlay({ label = 'Loading...' }) {
  return (
    <View style={styles.wrap}>
      <ActivityIndicator size="large" />
      <Text style={styles.txt}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: colors.background },
  txt: { color: colors.muted }
});
